﻿
//Check for main namespace
if (typeof Misc_CommitteeMembers === 'undefined') {
    // Namespace does not exist, create a new one
    var Misc_CommitteeMembers = {};
}

//Add the event handlers container object to the main namespace
Misc_CommitteeMembers.EventHandlers = {};















