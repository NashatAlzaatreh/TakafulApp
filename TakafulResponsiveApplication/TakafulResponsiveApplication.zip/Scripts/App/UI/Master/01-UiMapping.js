﻿
//Check for main namespace
if (typeof MasterPage === 'undefined') {
    // Namespace does not exist, create a new one
    var MasterPage = {};
}


//Add the ui elements container object to the main namespace
MasterPage.uiElements = {};

//Map each ui element to a variable
MasterPage.uiElements.ulInternalMenu_Small = "ulInternalMenu_Small";
MasterPage.uiElements.ulInternalMenu_Large = "ulInternalMenu_Large";

















