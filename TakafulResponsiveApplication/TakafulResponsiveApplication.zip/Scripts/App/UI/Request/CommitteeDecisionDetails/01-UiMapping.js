﻿
//Check for main namespace
if (typeof Request_CommitteeDecisionDetails === 'undefined') {
    // Namespace does not exist, create a new one
    var Request_CommitteeDecisionDetails = {};
}


//Add the ui elements container object to the main namespace
Request_CommitteeDecisionDetails.uiElements = {};

//Map each ui element to a variable
Request_CommitteeDecisionDetails.uiElements.tblMembers = "tblMembers";
Request_CommitteeDecisionDetails.uiElements.btnHistoryBack = "btnHistoryBack";







