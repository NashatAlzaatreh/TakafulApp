﻿
//Check for main namespace
if (typeof Request_CommitteeDecisionDetails === 'undefined') {
    // Namespace does not exist, create a new one
    var Request_CommitteeDecisionDetails = {};
}

//Add the event handlers container object to the main namespace
Request_CommitteeDecisionDetails.EventHandlers = {};















