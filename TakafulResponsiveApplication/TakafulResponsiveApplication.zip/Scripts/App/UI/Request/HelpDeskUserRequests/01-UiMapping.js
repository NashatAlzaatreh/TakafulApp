﻿
//Check for main namespace
if (typeof Request_HelpDeskUserRequests === 'undefined') {
    // Namespace does not exist, create a new one
    var Request_HelpDeskUserRequests = {};
}


//Add the ui elements container object to the main namespace
Request_HelpDeskUserRequests.uiElements = {};

//Map each ui element to a variable
Request_HelpDeskUserRequests.uiElements.btnSearch = "btnSearch";
Request_HelpDeskUserRequests.uiElements.txtEmployeeNumber = "txtEmployeeNumber";
//Request_HelpDeskUserRequests.uiElements.txtName = "txtName";
Request_HelpDeskUserRequests.uiElements.tblRequests = "tblRequests";








