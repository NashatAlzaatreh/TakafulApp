﻿

$(document).ready(function () {

    //Namespaces
    (function () {

        if (typeof Request_UserRequests === 'undefined') {
            // The master namespace of the page does not exist, the page can not run
            alert('This page has scripting errors and cannot be run.');
            return;
        }

        if (typeof Request_UserRequests.uiElements === 'undefined') {
            // The 'UI elements' namespace of the page does not exist, the page can not run
            alert('This page has scripting errors and cannot be run.');
            return;
        }

        if (typeof Request_UserRequests.EventHandlers === 'undefined') {
            // The 'event handlers' namespace of the page does not exist, the page can not run
            alert('This page has scripting errors and cannot be run.');
            return;
        }

        if (typeof Request_UserRequests.CustomMethods === 'undefined') {
            // The 'event handlers' namespace of the page does not exist, the page can not run
            alert('This page has scripting errors and cannot be run.');
            return;
        }

    }());

    Request_UserRequests.ServiceUrl = Takaful.Config.ServiceUrl_Main + "/Request_UserRequests";
    Request_UserRequests.InitialDataReady = false;


    //Reset UI elements
    Request_UserRequests.CustomMethods.LocalOperations.ResetUI();

    //Get initial data
    Request_UserRequests.CustomMethods.AjaxCall.GetInitialData();

    //History back button
    $("#" + Request_UserRequests.uiElements.btnHistoryBack).bind("click", function () { window.history.back(); });

    //Check if all procedures completed
    var mainTimerHndler = setInterval(function () {
        if (MasterPage.IsReady == true && Request_UserRequests.InitialDataReady == true) {
            //Initialize foundation
            $(document).foundation();

            //Hide loading screen
            Takaful.CommonMethods.HideLoading();

            //Terminate the timer
            clearInterval(mainTimerHndler);
        }

    }, 100);

});


