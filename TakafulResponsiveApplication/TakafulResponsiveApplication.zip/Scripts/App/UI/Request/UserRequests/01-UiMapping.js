﻿
//Check for main namespace
if (typeof Request_UserRequests === 'undefined') {
    // Namespace does not exist, create a new one
    var Request_UserRequests = {};
}


//Add the ui elements container object to the main namespace
Request_UserRequests.uiElements = {};

//Map each ui element to a variable
Request_UserRequests.uiElements.tblRequests = "tblRequests";
Request_UserRequests.uiElements.btnHistoryBack = "btnHistoryBack";







