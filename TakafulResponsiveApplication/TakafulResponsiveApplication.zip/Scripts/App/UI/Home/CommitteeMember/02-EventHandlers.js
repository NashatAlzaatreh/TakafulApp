﻿
//Check for main namespace
if (typeof Home_CommitteeMember === 'undefined') {
    // Namespace does not exist, create a new one
    var Home_CommitteeMember = {};
}

//Add the event handlers container object to the main namespace
Home_CommitteeMember.EventHandlers = {};
















