﻿
//Check for main namespace
if (typeof Home_HelpDesk === 'undefined') {
    // Namespace does not exist, create a new one
    var Home_HelpDesk = {};
}

//Add the event handlers container object to the main namespace
Home_HelpDesk.EventHandlers = {};
















