﻿
//Check for main namespace
if (typeof Home_Start === 'undefined') {
    // Namespace does not exist, create a new one
    var Home_Start = {};
}

//Add the event handlers container object to the main namespace
Home_Start.EventHandlers = {};
















