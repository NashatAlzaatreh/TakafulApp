﻿
//Check for main namespace
if (typeof Home_Start === 'undefined') {
    // Namespace does not exist, create a new one
    var Home_Start = {};
}


//Add the ui elements container object to the main namespace
Home_Start.uiElements = {};

//Map each ui element to a variable
Home_Start.uiElements.divAdmin = "divAdmin";
Home_Start.uiElements.divCommitteeMember = "divCommitteeMember";
Home_Start.uiElements.divHelpDesk = "divHelpDesk";
Home_Start.uiElements.divEmployee = "divEmployee";










