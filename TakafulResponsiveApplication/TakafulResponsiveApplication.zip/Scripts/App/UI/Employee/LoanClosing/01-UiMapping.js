﻿
//Check for main namespace
if (typeof Employee_LoanClosing === 'undefined') {
    // Namespace does not exist, create a new one
    var Employee_LoanClosing = {};
}


//Add the ui elements container object to the main namespace
Employee_LoanClosing.uiElements = {};

//Map each ui element to a variable
Employee_LoanClosing.uiElements.chkEmployees = "chkEmployees";
Employee_LoanClosing.uiElements.tblEmployees = "tblEmployees";
Employee_LoanClosing.uiElements.btnSave = "btnSave";
Employee_LoanClosing.uiElements.btnExport = "btnExport";

Employee_LoanClosing.uiElements.chkEmployees2 = "chkEmployees2";
Employee_LoanClosing.uiElements.tblEmployees2 = "tblEmployees2";
Employee_LoanClosing.uiElements.btnSave2 = "btnSave2";
Employee_LoanClosing.uiElements.btnExport2 = "btnExport2";

Employee_LoanClosing.uiElements.btnHistoryBack = "btnHistoryBack";







