﻿
//Check for main namespace
if (typeof User_RestorePassword === 'undefined') {
    // Namespace does not exist, create a new one
    var User_RestorePassword = {};
}


//Add the ui elements container object to the main namespace
User_RestorePassword.uiElements = {};

//Map each ui element to a variable
User_RestorePassword.uiElements.txtEmployeeNumber = "txtEmployeeNumber";
User_RestorePassword.uiElements.txtEmail = "txtEmail";
User_RestorePassword.uiElements.btnSend = "btnSend";
User_RestorePassword.uiElements.btnHistoryBack = "btnHistoryBack";





